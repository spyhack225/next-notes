import Foundation

/// Authored producer controls; no model latency claim.
enum SmartTurnEndpointSelfTest {
    static func failures() async -> [String] {
        var failures: [String] = []
        func expect(_ condition: Bool, _ name: String) { if !condition { failures.append(name) } }
        for quiet in [0.2, 0.4, 0.6, 0.9, 1.2, 1.5, 2.5] {
            expect(SmartTurnEndpointPolicy.decide(quiet: quiet, probability: 0.1,
                inferencePending: false, modelAvailable: true, transcriptReady: true,
                legacyEligible: true) == .wait, "incomplete pause \(quiet) committed")
        }
        expect(SmartTurnEndpointPolicy.decide(quiet: 0.2, probability: 0.8, inferencePending: false,
            modelAvailable: true, transcriptReady: true, legacyEligible: false) == .complete,
            "complete question waited for Parakeet EOU")
        expect(SmartTurnEndpointPolicy.decide(quiet: 0.9, probability: 0.8, inferencePending: false,
            modelAvailable: true, transcriptReady: false, legacyEligible: true) == .wait,
            "usable processed transcript was bypassed")
        expect(SmartTurnEndpointPolicy.decide(quiet: 0.19, probability: 0.8, inferencePending: false,
            modelAvailable: true, transcriptReady: true, legacyEligible: true) == .wait,
            "speech/pause boundary was bypassed")
        expect(SmartTurnEndpointPolicy.decide(quiet: 0.9, probability: nil, inferencePending: false,
            modelAvailable: false, transcriptReady: true, legacyEligible: true) == .fallback,
            "missing artifact disabled the existing fallback")
        expect(SmartTurnEndpointPolicy.decide(quiet: 0.9, probability: nil, inferencePending: true,
            modelAvailable: true, transcriptReady: true, legacyEligible: true) == .wait,
            "live inference was bypassed")
        expect(SmartTurnEndpointPolicy.decide(quiet: 5, probability: 0.1, inferencePending: false,
            modelAvailable: true, transcriptReady: true, legacyEligible: true) == .fallback,
            "incomplete maximum-quiet fallback was lost")
        let state = SmartTurnEndpoint(captureID: UUID(), epoch: 1,
            cachedOnly: true, skipModelForTesting: true)
        let voice = [Float](repeating: 0.2, count: 8_000)
        voice.withUnsafeBufferPointer { _ = state.append($0, nearSpeech: true) }
        let first = state.evaluate(now: 1_000_000_000, usableText: true,
            transcriptStable: true, localText: true, legacyEligible: true)
        expect(state.stillCurrent(first.token), "fresh token lost authority")
        voice.withUnsafeBufferPointer { _ = state.append($0, nearSpeech: true) }
        expect(!state.stillCurrent(first.token), "resumed speech retained stale completion authority")
        let second = state.evaluate(now: 1_100_000_000, usableText: true,
            transcriptStable: true, localText: true, legacyEligible: true)
        state.reset(epoch: 2)
        expect(!state.stillCurrent(second.token), "reset retained old turn authority")
        await state.close().value
        expect(!state.stillCurrent(second.token), "closed capture retained authority")
        return failures
    }
}
